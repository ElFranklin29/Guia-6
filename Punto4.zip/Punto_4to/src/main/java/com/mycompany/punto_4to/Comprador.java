/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.punto_4to;

/**
 *
 * @author josephp
 */
public class Comprador extends Thread{
    private final DatosCompartidos data;

    public Comprador(DatosCompartidos data) {
        this.data = data;
    }

    @Override
    public void run() {
        while (true) {
            int number = data.getNumber();
            int result = number * 2; // Multiplica por 2
            System.out.println("Consumidor procesó: " + number + ", Resultado: " + result);
            try {
                Thread.sleep(1000); // Espera un segundo
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}