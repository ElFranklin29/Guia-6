/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.punto_4to;
import java.util.Random;
/**
 *
 * @author josephp
 */
    

public class Productor extends Thread {
    private final DatosCompartidos data;

    public Productor(DatosCompartidos data) {
        this.data = data;
    }

    @Override
    public void run() {
        Random random = new Random();
        while (true) {
            int number = random.nextInt(100) + 1; // Genera un número entre 1 y 100
            data.setNumber(number);
            System.out.println("Productor generó: " + number);
            try {
                Thread.sleep(500); // Espera medio segundo
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

