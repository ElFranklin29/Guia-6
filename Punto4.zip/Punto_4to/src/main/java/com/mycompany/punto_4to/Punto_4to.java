/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.punto_4to;

/**
 *
 * @author josephp
 */
public class Punto_4to {

    public static void main(String[] args) {
        DatosCompartidos data = new DatosCompartidos();
        Thread producerThread = new Productor(data);
        Thread consumerThread = new Comprador(data);

        producerThread.start();
        consumerThread.start();
    }
}

