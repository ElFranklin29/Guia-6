/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.punto_4to;

/**
 *
 * @author josephp
 */
public class DatosCompartidos {
    private int number;
    private boolean hasNewData = false;

    public synchronized void setNumber(int number) {
        while (hasNewData) {
            try {
                wait(); // Espera si ya hay un número disponible
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        this.number = number;
        hasNewData = true;
        notifyAll(); // Notifica al consumidor que hay un nuevo número
    }

    public synchronized int getNumber() {
        while (!hasNewData) {
            try {
                wait(); // Espera si no hay un número disponible
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        hasNewData = false;
        notifyAll(); // Notifica al productor que se ha consumido un número
        return number;
    }
}
