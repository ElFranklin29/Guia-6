/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package punto2;

/**
 *
 * @author Franklin
 */
public class Llamada {

    private Telefono telefono;

    public Llamada(Telefono telefono) {
        this.telefono = telefono;
    }

    public Telefono getTelefono() {
        return telefono;
    }

    public void realizarLlamada() {
        System.out.println("Llamando al número: " + telefono.getNumero());
        try {
            Thread.sleep(2000); 
        } catch (InterruptedException e) {
            System.out.println("La llamada fue interrumpida");
        }
        System.out.println("Llamada finalizada con el número: " + telefono.getNumero());
    }

}
