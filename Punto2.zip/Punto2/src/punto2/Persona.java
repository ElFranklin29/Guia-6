package punto2;

public class Persona implements Runnable {

    private String nombre;
    private Llamada llamada;

    public Persona(String nombre, Llamada llamada) {
        this.nombre = nombre;
        this.llamada = llamada;
    }

    public void run() {
        System.out.println(nombre + " está realizando una llamada...");
        llamada.realizarLlamada();
        System.out.println(nombre + " terminó la llamada.");
    }

}
