
package punto2;

public class Main {
    public static void main(String[] args) {
        
        Telefono telefono1 = new Telefono("123-4567");
        Telefono telefono2 = new Telefono("890-1234");

     
        Llamada llamada1 = new Llamada(telefono1);
        Llamada llamada2 = new Llamada(telefono2);


        Persona persona1 = new Persona("Alice", llamada1);
        Persona persona2 = new Persona("Bob", llamada2);

      
        Thread hilo1 = new Thread(persona1);
        Thread hilo2 = new Thread(persona2);

  
        hilo1.start();
        hilo2.start();

       
        try {
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Finalizado");
    }
}
